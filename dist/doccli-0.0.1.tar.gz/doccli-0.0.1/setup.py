# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['doccli']

package_data = \
{'': ['*']}

install_requires = \
['decli>=0.5.1,<0.6.0', 'docstring-parser>=0.3,<0.4']

setup_kwargs = {
    'name': 'doccli',
    'version': '0.0.1',
    'description': 'Build Config classes that can be quickly turned into CLI specifications',
    'long_description': None,
    'author': 'mayansalama',
    'author_email': 'micsalama@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
